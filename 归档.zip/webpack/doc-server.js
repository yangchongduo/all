/**
 * Created by yixi on 3/29/16.
 */
require("babel-register");
var config = require('./doc.config.js');
module.exports = config;
