/**
 * Created by yixi on 1/29/16.
 */
import React from 'react';

export default React.createClass({
    displayName: 'progress',

    render() {
        return (
            <div>这是一个碉堡的进度条组件</div>
        );
    }
});
