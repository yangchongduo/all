/**
 * Created by yixi on 3/30/16.
 */
import React, {Component} from 'react';

export default class menu extends Component {
    render() {
        return (
            <div id="mainMenu">
                menu
            </div>
        )
    }
}
