/**
 * Created by yixi on 3/30/16.
 */
import React, {Component} from 'react';

export default class app extends Component {
    render() {
        return (
            <header id="header">
                <div className="title">React-Meiqia-UI</div>
            </header>
        )
    }
}
