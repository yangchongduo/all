/**
 * Created by yixi on 3/29/16.
 */

import ReactDom from 'react-dom';
import React from 'react';
import App from './layout/app';

ReactDom.render(<App />, document.getElementById('mainWrapper'));
