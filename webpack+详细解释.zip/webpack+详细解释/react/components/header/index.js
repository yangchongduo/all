import React from 'react';
import styles from './index.css'
export default class Header extends React.Component{
    render(){
        return (
            <h1 className={styles.index}>我是头33333</h1>
        )
    }
}