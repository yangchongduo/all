import React from 'react';
import styles from './index.css'
export default class Footer extends React.Component{
    render(){
        return (
            <h1 className={styles.index}>我是脚2</h1>
        )
    }
}