import React from 'react';
import {Header,Footer} from './components';
import ReactDOM from 'react-dom';

ReactDOM.render(<div>
    <Header/>
    <input/>
    <Footer/>
</div>,document.querySelector('#app'));



