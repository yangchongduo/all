var React = require('react');
console.log(React);