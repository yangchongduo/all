import {name} from './component';
document.write('a:'+name);
import $ from 'jquery';