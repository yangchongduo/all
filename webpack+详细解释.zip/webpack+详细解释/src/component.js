export var name =  'hello9';
import {age} from './component2'