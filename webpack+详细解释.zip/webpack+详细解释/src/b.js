import {name} from './component';
document.write('b:'+name);
import $ from 'jquery';